package dao;

import db.DBConnection;
import model.Book;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {

    // --- Add a new Book (physical book)
    public boolean addBook(Book book) {
        boolean success = false;
        String query = "INSERT INTO books (title, author, category, available, publisher, edition, isbn, quantity) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            ps.setString(3, book.getCategory());
            ps.setBoolean(4, book.isAvailable());
            ps.setString(5, book.getPublisher());
            ps.setString(6, book.getEdition());
            ps.setString(7, book.getIsbn());
            ps.setInt(8, book.getQuantity());

            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }

    // --- Update an existing book
    public boolean updateBook(Book book) {
        boolean success = false;
        String query = "UPDATE books SET title=?, author=?, category=?, available=?, publisher=?, edition=?, isbn=?, quantity=? WHERE book_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            ps.setString(3, book.getCategory());
            ps.setBoolean(4, book.isAvailable());
            ps.setString(5, book.getPublisher());
            ps.setString(6, book.getEdition());
            ps.setString(7, book.getIsbn());
            ps.setInt(8, book.getQuantity());
            ps.setInt(9, book.getBookId());

            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }

    // --- Delete a book by ID
    public boolean deleteBook(int bookId) {
        boolean success = false;
        String query = "DELETE FROM books WHERE book_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, bookId);
            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }

    // --- Get all books
    public List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();
        String query = "SELECT * FROM books";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Book book = new Book(
                        rs.getInt("book_id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("category"),
                        rs.getBoolean("available"),  // ✅ boolean here
                        rs.getString("publisher"),
                        rs.getString("edition"),
                        rs.getString("isbn"),
                        rs.getInt("quantity")
                );
                books.add(book);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return books;
    }

    // --- Search books by keyword
    public List<Book> searchBooks(String keyword) {
        List<Book> books = new ArrayList<>();
        String query = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            String searchKeyword = "%" + keyword + "%";
            ps.setString(1, searchKeyword);
            ps.setString(2, searchKeyword);
            ps.setString(3, searchKeyword);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Book book = new Book(
                        rs.getInt("book_id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("category"),
                        rs.getBoolean("available"),  // ✅ fix: available here
                        rs.getString("publisher"),
                        rs.getString("edition"),
                        rs.getString("isbn"),
                        rs.getInt("quantity")
                );
                books.add(book);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return books;
    }

    // --- Get a single book by ID
    public Book getBookById(int bookId) {
        String query = "SELECT * FROM books WHERE book_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, bookId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Book(
                            rs.getInt("book_id"),
                            rs.getString("title"),
                            rs.getString("author"),
                            rs.getString("category"),
                            rs.getBoolean("available"),  // ✅ boolean here
                            rs.getString("publisher"),
                            rs.getString("edition"),
                            rs.getString("isbn"),
                            rs.getInt("quantity")
                    );
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}


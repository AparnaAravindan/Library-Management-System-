package dao;

import db.DBConnection;
import model.SecondHandBook;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SecondHandBookDAO {

    // Save new second-hand book
    public static boolean saveBook(SecondHandBook book) {
        String sql = "INSERT INTO secondhand_books " +
                "(title, author, publisher, edition, book_condition, price, photo_path, uploaded_by, status) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, book.getTitle());
            stmt.setString(2, book.getAuthor());
            stmt.setString(3, book.getPublisher());
            stmt.setString(4, book.getEdition());
            stmt.setString(5, book.getBookCondition());
            stmt.setDouble(6, book.getPrice());
            stmt.setString(7, book.getPhotoPath());
            stmt.setString(8, book.getUploadedBy());
            stmt.setString(9, book.getStatus());

            return stmt.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Get pending books for admin approval
    public static List<SecondHandBook> getPendingBooks() {
        List<SecondHandBook> books = new ArrayList<>();
        String sql = "SELECT * FROM secondhand_books WHERE status = 'pending'";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                books.add(new SecondHandBook(
                        rs.getInt("book_id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("publisher"),
                        rs.getString("edition"),
                        rs.getString("book_condition"),
                        rs.getDouble("price"),
                        rs.getString("photo_path"),
                        rs.getString("uploaded_by"),
                        rs.getString("status"),
                        rs.getString("upload_date")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return books;
    }

    // Get approved (available) books
    public static List<SecondHandBook> getApprovedBooks() {
        List<SecondHandBook> books = new ArrayList<>();
        String sql = "SELECT * FROM secondhand_books WHERE status = 'approved' AND sold = false";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                books.add(new SecondHandBook(
                        rs.getInt("book_id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("publisher"),
                        rs.getString("edition"),
                        rs.getString("book_condition"),
                        rs.getDouble("price"),
                        rs.getString("photo_path"),
                        rs.getString("uploaded_by"),
                        rs.getString("status"),
                        rs.getString("upload_date")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return books;
    }

    // Approve / Reject a book
    public static boolean updateBookStatus(int bookId, String status) {
        String sql = "UPDATE secondhand_books SET status = ? WHERE book_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, status);
            stmt.setInt(2, bookId);
            return stmt.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Mark book as sold
    public static boolean markAsSold(int bookId) {
        String sql = "UPDATE secondhand_books SET sold = true WHERE book_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, bookId);
            return stmt.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}

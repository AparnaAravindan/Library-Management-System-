package dao;

import db.DBConnection;
import model.DonatedBook;

import java.sql.*;
import java.util.*;

public class DonationDAO {

    // ✅ Save a new donation (insert into DB)
    public static boolean saveDonation(DonatedBook book) {
        String sql = "INSERT INTO donated_books " +
                     "(title, author, publisher, edition, book_condition, photo_path, uploaded_by, status, isbn) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, book.getTitle());
                stmt.setString(2, book.getAuthor());
                stmt.setString(3, book.getPublisher());
                stmt.setString(4, book.getEdition());
                stmt.setString(5, book.getBookCondition());
                stmt.setString(6, book.getPhotoPath());
                stmt.setString(7, book.getUploadedBy());
                stmt.setString(8, book.getStatus());
                stmt.setString(9, book.getIsbn());   // ✅ added

                return stmt.executeUpdate() > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // ✅ Get pending donations for admin approval
    public static List<DonatedBook> getPendingDonations() {
        List<DonatedBook> donations = new ArrayList<>();
        String sql = "SELECT * FROM donated_books WHERE status = 'pending'";

        try {
            try (Connection conn = DBConnection.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {

                while (rs.next()) {
                    DonatedBook book = new DonatedBook(
                            rs.getInt("donate_id"),
                            rs.getString("title"),
                            rs.getString("author"),
                            rs.getString("publisher"),
                            rs.getString("edition"),
                            rs.getString("book_condition"),
                            rs.getString("photo_path"),
                            rs.getString("uploaded_by"),
                            rs.getString("status"),
                            rs.getString("upload_date"),
                            rs.getString("isbn")  // ✅ fixed comma issue
                    );
                    donations.add(book);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return donations;
    }

    // ✅ Approve / Reject donation
    public static boolean updateDonationStatus(int donateId, String status) {
        String sql = "UPDATE donated_books SET status = ? WHERE donate_id = ?";

        try {
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, status);
                stmt.setInt(2, donateId);

                return stmt.executeUpdate() > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}


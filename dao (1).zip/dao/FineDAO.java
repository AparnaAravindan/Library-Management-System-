package dao;

import db.DBConnection;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import model.FineRecord;

public class FineDAO {
    private static final int FINE_RATE = 10; // ₹10 per late day

    public List<FineRecord> getAllFines() {
        List<FineRecord> fines = new ArrayList<>();

        String query = "SELECT b.title, u.username, ib.due_date, ib.return_date " +
                       "FROM issued_books ib " +
                       "JOIN books b ON ib.book_id = b.book_id " +
                       "JOIN users u ON ib.user_id = u.user_id";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String bookTitle = rs.getString("title");
                String username = rs.getString("username");
                LocalDate dueDate = rs.getDate("due_date").toLocalDate();
                Date returnDateSql = rs.getDate("return_date");
                LocalDate returnDate = (returnDateSql != null) ? returnDateSql.toLocalDate() : null;

                // Fine calculation
                LocalDate calcDate = (returnDate != null) ? returnDate : LocalDate.now();
                long lateDays = java.time.temporal.ChronoUnit.DAYS.between(dueDate, calcDate);
                int fine = (lateDays > 0) ? (int) lateDays * FINE_RATE : 0;

                fines.add(new FineRecord(username, bookTitle, dueDate, returnDate, fine));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return fines;
    }
}


package dao;

import db.DBConnection;
import java.sql.*;
import java.time.LocalDate;

public class BorrowDAO {

    /**
     * Borrow a book for a user.
     * Returns true on success, false if book not available or on error.
     */
    public boolean borrowBook(int userId, int bookId) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                // Check available copies
                String q1 = "SELECT available FROM books WHERE book_id = ? FOR UPDATE";
                try (PreparedStatement ps1 = conn.prepareStatement(q1)) {
                    ps1.setInt(1, bookId);
                    try (ResultSet rs = ps1.executeQuery()) {
                        if (!rs.next()) { conn.rollback(); return false; }
                        if (rs.getInt("available") <= 0) { conn.rollback(); return false; }
                    }
                }

                // Insert borrow record
                String ins = "INSERT INTO borrowed_books (user_id, book_id, borrow_date, returned) VALUES (?, ?, ?, 0)";
                try (PreparedStatement ps = conn.prepareStatement(ins)) {
                    ps.setInt(1, userId);
                    ps.setInt(2, bookId);
                    ps.setDate(3, Date.valueOf(LocalDate.now()));
                    ps.executeUpdate();
                }

                // Decrement availability
                String upd = "UPDATE books SET available = available - 1 WHERE book_id = ?";
                try (PreparedStatement ps = conn.prepareStatement(upd)) {
                    ps.setInt(1, bookId);
                    ps.executeUpdate();
                }

                conn.commit();
                return true;
            } catch (Exception ex) {
                conn.rollback();
                ex.printStackTrace();
                return false;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Original return method by borrowId (kept for internal use)
     */
    public boolean returnBook(int borrowId) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                // Get book_id and returned flag
                String sel = "SELECT book_id, returned FROM borrowed_books WHERE borrow_id = ? FOR UPDATE";
                int bookId;
                boolean alreadyReturned;
                try (PreparedStatement ps = conn.prepareStatement(sel)) {
                    ps.setInt(1, borrowId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) { conn.rollback(); return false; }
                        bookId = rs.getInt("book_id");
                        alreadyReturned = rs.getInt("returned") != 0;
                    }
                }

                if (alreadyReturned) { conn.rollback(); return false; }

                // Update borrowed_books
                String upTrans = "UPDATE borrowed_books SET return_date = ?, returned = 1 WHERE borrow_id = ?";
                try (PreparedStatement ps = conn.prepareStatement(upTrans)) {
                    ps.setDate(1, Date.valueOf(LocalDate.now()));
                    ps.setInt(2, borrowId);
                    ps.executeUpdate();
                }

                // Increment availability
                String upBook = "UPDATE books SET available = available + 1 WHERE book_id = ?";
                try (PreparedStatement ps = conn.prepareStatement(upBook)) {
                    ps.setInt(1, bookId);
                    ps.executeUpdate();
                }

                conn.commit();
                return true;
            } catch (Exception ex) {
                conn.rollback();
                ex.printStackTrace();
                return false;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Return a book by userId and bookId
     * Used in StudentDashboard to allow student to return their own book
     */
    public boolean returnBook(int userId, int bookId) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                // Find active borrow record for this user & book
                String sel = "SELECT borrow_id FROM borrowed_books WHERE user_id=? AND book_id=? AND returned=0 FOR UPDATE";
                int borrowId;
                try (PreparedStatement ps = conn.prepareStatement(sel)) {
                    ps.setInt(1, userId);
                    ps.setInt(2, bookId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) { conn.rollback(); return false; }
                        borrowId = rs.getInt("borrow_id");
                    }
                }

                // Update borrowed_books: set returned=1 and return_date=today
                String upTrans = "UPDATE borrowed_books SET returned=1, return_date=? WHERE borrow_id=?";
                try (PreparedStatement ps = conn.prepareStatement(upTrans)) {
                    ps.setDate(1, Date.valueOf(LocalDate.now()));
                    ps.setInt(2, borrowId);
                    ps.executeUpdate();
                }

                // Increment book availability
                String upBook = "UPDATE books SET available = available + 1 WHERE book_id=?";
                try (PreparedStatement ps = conn.prepareStatement(upBook)) {
                    ps.setInt(1, bookId);
                    ps.executeUpdate();
                }

                conn.commit();
                return true;
            } catch (Exception ex) {
                conn.rollback();
                ex.printStackTrace();
                return false;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Admin issues a book to a student
     * Sets borrow_date=today and return_date=borrow_date+14
     */
    public boolean adminIssueBook(int userId, int bookId) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                // Check availability
                String sel = "SELECT available FROM books WHERE book_id=? FOR UPDATE";
                int available;
                try (PreparedStatement ps = conn.prepareStatement(sel)) {
                    ps.setInt(1, bookId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) { conn.rollback(); return false; }
                        available = rs.getInt("available");
                        if (available <= 0) { conn.rollback(); return false; }
                    }
                }

                // Insert borrow record with due date = today + 14
                LocalDate borrowDate = LocalDate.now();
                LocalDate dueDate = borrowDate.plusDays(14);
                String ins = "INSERT INTO borrowed_books (user_id, book_id, borrow_date, return_date, returned) VALUES (?, ?, ?, ?, 0)";
                try (PreparedStatement ps = conn.prepareStatement(ins)) {
                    ps.setInt(1, userId);
                    ps.setInt(2, bookId);
                    ps.setDate(3, Date.valueOf(borrowDate));
                    ps.setDate(4, Date.valueOf(dueDate));
                    ps.executeUpdate();
                }

                // Decrement availability
                String upd = "UPDATE books SET available=available-1 WHERE book_id=?";
                try (PreparedStatement ps = conn.prepareStatement(upd)) {
                    ps.setInt(1, bookId);
                    ps.executeUpdate();
                }

                conn.commit();
                return true;
            } catch (Exception ex) {
                conn.rollback();
                ex.printStackTrace();
                return false;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}

package dao;

import java.sql.*;
import db.DBConnection;
import model.User;

public class UserDAO {

    // ✅ Return User instead of just true/false
    public User login(String username, String password, String role) {
        User user = null;
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM users WHERE username=? AND password=? AND role=?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, role);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                user = new User(
                        rs.getInt("user_id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user; // returns null if not found
    }

    // ✅ Register new user
    public boolean registerUser(String username, String password, String role) {
        boolean status = false;
        try (Connection conn = DBConnection.getConnection()) {
            String query = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, role);

            int rows = ps.executeUpdate();
            status = (rows > 0);
        } catch (SQLIntegrityConstraintViolationException e) {
            System.out.println("⚠️ Username already exists!");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    // ✅ Get userId by username (useful for borrow/return)
    public int getUserIdByUsername(String username) {
        try (Connection conn = DBConnection.getConnection()) {
            String q = "SELECT user_id FROM users WHERE username = ?";
            try (PreparedStatement ps = conn.prepareStatement(q)) {
                ps.setString(1, username);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return rs.getInt("user_id");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1; // not found / error
    }
}



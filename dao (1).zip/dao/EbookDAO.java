package dao;

import db.DBConnection;
import model.Ebook;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EbookDAO {

    // --- Fetch approved ebooks with search
    public List<Ebook> getApprovedEbooks(String keyword) {
        List<Ebook> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String q = "SELECT * FROM ebooks WHERE status='approved' AND (title LIKE ? OR subject LIKE ? OR author LIKE ?)";
            PreparedStatement ps = conn.prepareStatement(q);
            String search = "%" + keyword + "%";
            ps.setString(1, search);
            ps.setString(2, search);
            ps.setString(3, search);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Ebook eb = new Ebook();
                eb.setEbookId(rs.getInt("ebook_id"));
                eb.setTitle(rs.getString("title"));
                eb.setSubject(rs.getString("subject"));
                eb.setAuthor(rs.getString("author"));
                eb.setFilePath(rs.getString("file_path"));
                eb.setUploadedBy(rs.getString("uploaded_by"));
                eb.setStatus(rs.getString("status"));
                list.add(eb);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // --- Upload new ebook (pending status)
    public boolean uploadEbook(String title, String subject, String author, String filePath, String uploadedBy) {
        try (Connection conn = DBConnection.getConnection()) {
            String q = "INSERT INTO ebooks (title, subject, author, file_path, uploaded_by, status) VALUES (?, ?, ?, ?, ?, 'pending')";
            PreparedStatement ps = conn.prepareStatement(q);
            ps.setString(1, title);
            ps.setString(2, subject);
            ps.setString(3, author);
            ps.setString(4, filePath);
            ps.setString(5, uploadedBy);

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // --- Get file path by ebook id
    public String getFilePathById(int ebookId) {
        try (Connection conn = DBConnection.getConnection()) {
            String q = "SELECT file_path FROM ebooks WHERE ebook_id=?";
            PreparedStatement ps = conn.prepareStatement(q);
            ps.setInt(1, ebookId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("file_path");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // --- Get all pending ebooks
    public List<Ebook> getPendingEbooks() {
        List<Ebook> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String q = "SELECT * FROM ebooks WHERE status='pending'";
            PreparedStatement ps = conn.prepareStatement(q);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Ebook eb = new Ebook();
                eb.setEbookId(rs.getInt("ebook_id"));
                eb.setTitle(rs.getString("title"));
                eb.setAuthor(rs.getString("author"));
                eb.setSubject(rs.getString("subject"));
                eb.setFilePath(rs.getString("file_path"));
                eb.setUploadedBy(rs.getString("uploaded_by"));
                eb.setStatus(rs.getString("status"));
                list.add(eb);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // --- Update ebook status
    public boolean updateEbookStatus(int ebookId, String status) {
        try (Connection conn = DBConnection.getConnection()) {
            String q = "UPDATE ebooks SET status=? WHERE ebook_id=?";
            PreparedStatement ps = conn.prepareStatement(q);
            ps.setString(1, status);
            ps.setInt(2, ebookId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // --- Add a new ebook
    public boolean addEbook(Ebook ebook) {
        try (Connection conn = DBConnection.getConnection()) {
            String q = "INSERT INTO ebooks (title, subject, author, file_path, uploaded_by, status) VALUES (?, ?, ?, ?, ?, 'pending')";
            PreparedStatement ps = conn.prepareStatement(q);
            ps.setString(1, ebook.getTitle());
            ps.setString(2, ebook.getSubject());
            ps.setString(3, ebook.getAuthor());
            ps.setString(4, ebook.getFilePath());
            ps.setString(5, ebook.getUploadedBy());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // --- Get single ebook by ID
    public Ebook getEbookById(int ebookId) {
        try (Connection conn = DBConnection.getConnection()) {
            String q = "SELECT * FROM ebooks WHERE ebook_id=?";
            PreparedStatement ps = conn.prepareStatement(q);
            ps.setInt(1, ebookId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Ebook eb = new Ebook();
                eb.setEbookId(rs.getInt("ebook_id"));
                eb.setTitle(rs.getString("title"));
                eb.setSubject(rs.getString("subject"));
                eb.setAuthor(rs.getString("author"));
                eb.setFilePath(rs.getString("file_path"));
                eb.setUploadedBy(rs.getString("uploaded_by"));
                eb.setStatus(rs.getString("status"));
                return eb;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // --- Update ebook details
    public boolean updateEbook(Ebook ebook) {
        try (Connection conn = DBConnection.getConnection()) {
            String q = "UPDATE ebooks SET title=?, subject=?, author=?, file_path=?, uploaded_by=? WHERE ebook_id=?";
            PreparedStatement ps = conn.prepareStatement(q);
            ps.setString(1, ebook.getTitle());
            ps.setString(2, ebook.getSubject());
            ps.setString(3, ebook.getAuthor());
            ps.setString(4, ebook.getFilePath());
            ps.setString(5, ebook.getUploadedBy());
            ps.setInt(6, ebook.getEbookId());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public boolean deleteEbook(int ebookId) {
    try (Connection conn = DBConnection.getConnection()) {
        String q = "DELETE FROM ebooks WHERE ebook_id=?";
        PreparedStatement ps = conn.prepareStatement(q);
        ps.setInt(1, ebookId);
        return ps.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

}

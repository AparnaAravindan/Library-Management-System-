package ui;

import dao.FineDAO;
import model.FineRecord;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class FineCalculationUI extends JFrame {

    public FineCalculationUI() {
        setTitle("Fine Calculation");
        setSize(700, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        String[] columnNames = {"Username", "Book Title", "Due Date", "Return Date", "Fine (₹)"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        FineDAO fineDAO = new FineDAO();
        List<FineRecord> fines = fineDAO.getAllFines();

        for (FineRecord record : fines) {
            model.addRow(new Object[]{
                    record.getUsername(),
                    record.getBookTitle(),
                    record.getDueDate(),
                    record.getReturnDate() != null ? record.getReturnDate() : "Not Returned",
                    record.getFine()
            });
        }

        add(scrollPane, BorderLayout.CENTER);
    }
}


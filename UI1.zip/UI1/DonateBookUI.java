package ui;

import dao.DonationDAO;
import model.DonatedBook;

import javax.swing.*;
import java.awt.*;

public class DonateBookUI extends JFrame {
    private JTextField titleField, authorField, publisherField, editionField, isbnField;
    private JComboBox<String> conditionBox;
    private String username; // who is donating

    public DonateBookUI(String username) {
        this.username = username;

        setTitle("🎁 Donate a Book");
        setSize(400, 450);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(8, 2, 10, 10));

        panel.add(new JLabel("Title:"));
        titleField = new JTextField();
        panel.add(titleField);

        panel.add(new JLabel("Author:"));
        authorField = new JTextField();
        panel.add(authorField);

        panel.add(new JLabel("Publisher:"));
        publisherField = new JTextField();
        panel.add(publisherField);

        panel.add(new JLabel("Edition:"));
        editionField = new JTextField();
        panel.add(editionField);

        panel.add(new JLabel("Condition:"));
        conditionBox = new JComboBox<>(new String[]{"Bad", "Average", "New"});
        panel.add(conditionBox);

        panel.add(new JLabel("ISBN:"));
        isbnField = new JTextField();
        panel.add(isbnField);

        JButton submitBtn = new JButton("✅ Submit Donation");
        JButton cancelBtn = new JButton("❌ Cancel");

        panel.add(submitBtn);
        panel.add(cancelBtn);

        add(panel);

        submitBtn.addActionListener(e -> submitDonation());
        cancelBtn.addActionListener(e -> dispose());

        setVisible(true);
    }

    private void submitDonation() {
        String title = titleField.getText().trim();
        String author = authorField.getText().trim();
        String publisher = publisherField.getText().trim();
        String edition = editionField.getText().trim();
        String condition = conditionBox.getSelectedItem().toString();
        String isbn = isbnField.getText().trim();

        if (title.isEmpty() || isbn.isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠️ Title and ISBN are required!");
            return;
        }

        DonatedBook book = new DonatedBook(
                title,
                author,
                publisher,
                edition,
                condition,
                null,        // photoPath (optional, not used now)
                username,    // uploadedBy (string, like student username)
                "pending",
                isbn         // ✅ added ISBN
        );

        boolean saved = DonationDAO.saveDonation(book);
        if (saved) {
            JOptionPane.showMessageDialog(this, "🎉 Thank you! Your donation is awaiting approval.");
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "❌ Error saving donation.");
        }
    }
}


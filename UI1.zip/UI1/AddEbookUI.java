package ui;

import dao.EbookDAO;
import model.Ebook;

import javax.swing.*;
import java.awt.*;

public class AddEbookUI extends JFrame {
    private JTextField titleField, pathField;

    public AddEbookUI() {
        setTitle("💻 Add Ebook");
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));

        titleField = new JTextField();
        pathField = new JTextField();

        panel.add(new JLabel("Title:")); panel.add(titleField);
        panel.add(new JLabel("File Path:")); panel.add(pathField);

        JButton addBtn = new JButton("Add Ebook");
        addBtn.addActionListener(e -> addEbook());
        panel.add(new JLabel(""));
        panel.add(addBtn);

        add(panel);
        setVisible(true);
    }

    private void addEbook() {
        Ebook ebook = new Ebook();
        ebook.setTitle(titleField.getText());
        ebook.setFilePath(pathField.getText());
        ebook.setUploadedBy("admin"); // or current user
        ebook.setStatus("pending");

        boolean success = new EbookDAO().addEbook(ebook);
        if (success) {
            JOptionPane.showMessageDialog(this, "✅ Ebook submitted for approval!");
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "❌ Failed to add ebook.");
        }
    }
}

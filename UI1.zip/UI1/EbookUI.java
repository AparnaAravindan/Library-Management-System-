package ui;

import dao.EbookDAO;
import model.Ebook;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.util.List;

public class EbookUI extends JFrame {

    private JTable ebookTable;
    private DefaultTableModel model;
    private JTextField searchField;
    private String loggedInUser; // from StudentDashboard

    public EbookUI(String username) {
        this.loggedInUser = username;

        setTitle("📚 E-Books Library");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel topPanel = new JPanel(new BorderLayout());
        searchField = new JTextField();
        JButton searchBtn = new JButton("🔍 Search");
        JButton uploadBtn = new JButton("📤 Upload E-Book");

        topPanel.add(searchField, BorderLayout.CENTER);
        topPanel.add(searchBtn, BorderLayout.EAST);
        topPanel.add(uploadBtn, BorderLayout.WEST);

        model = new DefaultTableModel(new String[]{"ID", "Title", "Author", "Subject", "Uploaded By"}, 0);
        ebookTable = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(ebookTable);

        JButton openBtn = new JButton("📖 Open Selected E-Book");

        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(openBtn, BorderLayout.SOUTH);

        // Load approved ebooks
        loadEbooks("");

        // Search action
        searchBtn.addActionListener(e -> {
            String keyword = searchField.getText();
            loadEbooks(keyword);
        });

        // Upload action
        uploadBtn.addActionListener(e -> uploadEbook());

        // Open selected ebook
        openBtn.addActionListener(e -> openSelectedEbook());
    }

    private void loadEbooks(String keyword) {
        model.setRowCount(0);
        List<Ebook> ebooks = new EbookDAO().getApprovedEbooks(keyword);
        for (Ebook eb : ebooks) {
            model.addRow(new Object[]{eb.getEbookId(), eb.getTitle(), eb.getAuthor(), eb.getSubject(), eb.getUploadedBy()});
        }
    }

    private void uploadEbook() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);

        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();

            String title = JOptionPane.showInputDialog(this, "Enter E-Book Title:");
            String subject = JOptionPane.showInputDialog(this, "Enter Subject:");
            String author = JOptionPane.showInputDialog(this, "Enter Author:");

            if (title == null || subject == null || author == null || title.isEmpty()) {
                JOptionPane.showMessageDialog(this, "❌ Title, Subject and Author required!");
                return;
            }

            boolean success = new EbookDAO().uploadEbook(title, subject, author, file.getAbsolutePath(), loggedInUser);
            if (success) {
                JOptionPane.showMessageDialog(this, "✅ E-Book uploaded! Awaiting admin approval.");
            } else {
                JOptionPane.showMessageDialog(this, "❌ Upload failed.");
            }
        }
    }

    private void openSelectedEbook() {
        int row = ebookTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "⚠️ Please select an ebook to open.");
            return;
        }

        int ebookId = (int) model.getValueAt(row, 0);
        String filePath = new EbookDAO().getFilePathById(ebookId);

        if (filePath != null) {
            try {
                Desktop.getDesktop().open(new File(filePath));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "❌ Cannot open file.");
            }
        }
    }
}

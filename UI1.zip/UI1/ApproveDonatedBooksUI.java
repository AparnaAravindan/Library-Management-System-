package ui;

import dao.DonationDAO;
import model.DonatedBook;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;


public class ApproveDonatedBooksUI extends JFrame {
    private JTable table;
    private DefaultTableModel model;

    public ApproveDonatedBooksUI() {
        setTitle("Approve Donated Books");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        model = new DefaultTableModel(new String[]{"ID", "Title", "Author", "Publisher", "Edition", "Condition", "Uploaded By", "Upload Date"}, 0);
        table = new JTable(model);
        loadPendingDonations();

        JScrollPane scrollPane = new JScrollPane(table);

        JButton approveBtn = new JButton("✅ Approve");
        JButton rejectBtn = new JButton("❌ Reject");

        approveBtn.addActionListener(e -> updateStatus("approved"));
        rejectBtn.addActionListener(e -> updateStatus("rejected"));

        JPanel btnPanel = new JPanel();
        btnPanel.add(approveBtn);
        btnPanel.add(rejectBtn);

        add(scrollPane, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);
    }

    private void loadPendingDonations() {
        model.setRowCount(0); // clear table
        List<DonatedBook> donations = DonationDAO.getPendingDonations();
        for (DonatedBook b : donations) {
            model.addRow(new Object[]{
                    b.getDonateId(),
                    b.getTitle(),
                    b.getAuthor(),
                    b.getPublisher(),
                    b.getEdition(),
                    b.getBookCondition(),
                    b.getUploadedBy(), // could fetch username via join if needed
                    b.getUploadDate()
            });
        }
    }

    private void updateStatus(String status) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "⚠ Please select a book to " + status);
            return;
        }

        int donateId = (int) model.getValueAt(selectedRow, 0);
        boolean success = DonationDAO.updateDonationStatus(donateId, status);

        if (success) {
            JOptionPane.showMessageDialog(this, "Book " + status + " successfully!");
            loadPendingDonations(); // refresh table
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update book status.");
        }
    }
}

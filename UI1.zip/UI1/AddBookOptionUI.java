package ui;

import javax.swing.*;
import java.awt.*;

public class AddBookOptionUI extends JFrame {
    public AddBookOptionUI() {
        setTitle("📚 Add Book");
        setSize(300, 150);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JButton physicalBtn = new JButton("📘 Physical Book");
        JButton ebookBtn = new JButton("💻 Ebook");

        physicalBtn.addActionListener(e -> new AddPhysicalBookUI());
        ebookBtn.addActionListener(e -> new AddEbookUI());

        JPanel panel = new JPanel(new GridLayout(2, 1, 10, 10));
        panel.add(physicalBtn);
        panel.add(ebookBtn);

        add(panel);
        setVisible(true);
    }
}

package ui;

import model.User;
import ui.AddBookOptionUI;
import ui.ApproveDonatedBooksUI;
import ui.ApproveSecondHandBooksUI;
import ui.DeleteBookUI;
import ui.DeleteEbookUI;
import ui.IssueBookUI;
import ui.LoginUI;
import ui.SearchBookUI;
import ui.UpdateBookUI;
import ui.UpdateEbookUI;
import ui.ViewSecondHandBooksUI;

import javax.swing.*;
import java.awt.*;

public class AdminDashboard extends JFrame {
    private User admin;

    public AdminDashboard(User admin) {
        this.admin = admin;

        setTitle("Admin Dashboard - " + admin.getUsername());
        setSize(600, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel
        JPanel panel = new JPanel(new GridLayout(10, 1, 10, 10));

        JLabel welcomeLabel = new JLabel("Welcome, Admin: " + admin.getUsername(), JLabel.CENTER);
        panel.add(welcomeLabel);

        // 🔍 Search Books
        JButton searchBookBtn = new JButton("🔍 Search Books");

        // 📚 Issue Book
        JButton issueBookBtn = new JButton("📖 Issue Book");

        // 📂 Manage Books (Add / Update / Delete)
        JButton addBookBtn = new JButton("➕ Add Book");
        JButton updateBookBtn = new JButton("✏️ Update Book");
        JButton deleteBookBtn = new JButton("🗑️ Delete Book");

        // 💰 Fine Calculation
        JButton fineCalcBtn = new JButton("💰 Fine Calculation");

        // ✅ Approvals
        JButton approveEBooksBtn = new JButton("✔️ Approve E-Books");
        JButton approveDonatedBtn = new JButton("✔️ Approve Donated Books");

        // 📖 Second-hand Books
        JButton secondHandBooksBtn = new JButton("📦 Second-hand Books");

        // 🚪 Logout
        JButton logoutBtn = new JButton("🚪 Logout");

        // Add buttons to panel
        panel.add(searchBookBtn);
        panel.add(issueBookBtn);
        panel.add(addBookBtn);
        panel.add(updateBookBtn);
        panel.add(deleteBookBtn);
        panel.add(fineCalcBtn);
        panel.add(approveEBooksBtn);
        panel.add(approveDonatedBtn);
        panel.add(secondHandBooksBtn);
        panel.add(logoutBtn);

        add(panel);

        // ✅ Button actions
        // ✅ Search Book button action
searchBookBtn.addActionListener(e -> {
    new SearchBookUI(); // open search book window
});

        issueBookBtn.addActionListener(e -> {
    new IssueBookUI();
});

        // 🔔 Add Book Popup
        addBookBtn.addActionListener(e -> {
    new AddBookOptionUI(); 
});

        updateBookBtn.addActionListener(e -> {
    String[] options = {"Physical Book", "E-Book"};
    int choice = JOptionPane.showOptionDialog(
            this,
            "What type of book do you want to update?",
            "Update Book",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]
    );

    if (choice == 0) {
        new UpdateBookUI().setVisible(true);   // ✅ Physical book update
    } else if (choice == 1) {
        new UpdateEbookUI().setVisible(true);  // ✅ Ebook update
    }
});

        deleteBookBtn.addActionListener(e -> {
    String[] options = {"Physical Book", "E-Book"};
    int choice = JOptionPane.showOptionDialog(
            this,
            "What type of book do you want to delete?",
            "Delete Book",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]
    );

    if (choice == 0) {
        new DeleteBookUI().setVisible(true);   // Physical book delete
    } else if (choice == 1) {
        new DeleteEbookUI().setVisible(true);  // E-book delete
    }
});



// Action


       fineCalcBtn.addActionListener(e -> {
    new FineCalculationUI().setVisible(true);
});

        approveEBooksBtn.addActionListener(e -> new ApproveEbookUI().setVisible(true));

        
        approveDonatedBtn.addActionListener(e -> {
        new ApproveDonatedBooksUI().setVisible(true);
        });
        secondHandBooksBtn.addActionListener(e -> {
    String[] options = {"Approve Second-Hand Books", "View Approved Books"};
    int choice = JOptionPane.showOptionDialog(
            this,
            "Choose an option:",
            "Second-Hand Books",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.INFORMATION_MESSAGE,
            null,
            options,
            options[0]
    );

    if (choice == 0) {
        new ApproveSecondHandBooksUI().setVisible(true);
    } else if (choice == 1) {
        new ViewSecondHandBooksUI().setVisible(true);
    }
        });


        logoutBtn.addActionListener(e -> {
            dispose();
            new LoginUI();
        });

        setVisible(true);
    }
}


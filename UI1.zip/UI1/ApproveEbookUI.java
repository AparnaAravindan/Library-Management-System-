package ui;

import dao.EbookDAO;
import model.Ebook;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ApproveEbookUI extends JFrame {

    private JTable ebookTable;
    private DefaultTableModel model;

    public ApproveEbookUI() {
        setTitle("📑 Approve Uploaded E-Books");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        model = new DefaultTableModel(new String[]{"ID", "Title", "Author", "Subject", "Uploaded By", "File Path"}, 0);
        ebookTable = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(ebookTable);

        JPanel btnPanel = new JPanel();
        JButton approveBtn = new JButton("✅ Approve");
        JButton rejectBtn = new JButton("❌ Reject");
        JButton refreshBtn = new JButton("🔄 Refresh");

        btnPanel.add(approveBtn);
        btnPanel.add(rejectBtn);
        btnPanel.add(refreshBtn);

        add(scrollPane, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);

        // Load pending ebooks
        loadPendingEbooks();

        // Button Actions
        approveBtn.addActionListener(e -> approveEbook());
        rejectBtn.addActionListener(e -> rejectEbook());
        refreshBtn.addActionListener(e -> loadPendingEbooks());
    }

    private void loadPendingEbooks() {
        model.setRowCount(0);
        List<Ebook> pending = new EbookDAO().getPendingEbooks();
        for (Ebook eb : pending) {
            model.addRow(new Object[]{eb.getEbookId(), eb.getTitle(), eb.getAuthor(), eb.getSubject(), eb.getUploadedBy(), eb.getFilePath()});
        }
    }

    private void approveEbook() {
        int row = ebookTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "⚠️ Select an ebook to approve.");
            return;
        }
        int ebookId = (int) model.getValueAt(row, 0);
        boolean success = new EbookDAO().updateEbookStatus(ebookId, "approved");
        if (success) {
            JOptionPane.showMessageDialog(this, "✅ E-Book Approved!");
            loadPendingEbooks();
        } else {
            JOptionPane.showMessageDialog(this, "❌ Error approving ebook.");
        }
    }

    private void rejectEbook() {
        int row = ebookTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "⚠️ Select an ebook to reject.");
            return;
        }
        int ebookId = (int) model.getValueAt(row, 0);
        boolean success = new EbookDAO().updateEbookStatus(ebookId, "rejected");
        if (success) {
            JOptionPane.showMessageDialog(this, "❌ E-Book Rejected.");
            loadPendingEbooks();
        } else {
            JOptionPane.showMessageDialog(this, "⚠️ Error rejecting ebook.");
        }
    }
}

package ui;

import dao.EbookDAO;

import javax.swing.*;
import java.awt.*;

public class DeleteEbookUI extends JFrame {

    private JTextField ebookIdField;
    private EbookDAO ebookDAO = new EbookDAO();

    public DeleteEbookUI() {
        setTitle("Delete E-Book");
        setSize(400, 200);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));

        panel.add(new JLabel("Enter E-Book ID:"));
        ebookIdField = new JTextField();
        panel.add(ebookIdField);

        JButton deleteBtn = new JButton("Delete E-Book");
        JButton cancelBtn = new JButton("Cancel");

        panel.add(deleteBtn);
        panel.add(cancelBtn);

        add(panel, BorderLayout.CENTER);

        deleteBtn.addActionListener(e -> deleteEbook());
        cancelBtn.addActionListener(e -> dispose());

        setVisible(true);
    }

    private void deleteEbook() {
        String idStr = ebookIdField.getText().trim();
        if (idStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter an E-Book ID.");
            return;
        }

        try {
            int ebookId = Integer.parseInt(idStr);

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete E-Book ID " + ebookId + "?",
                    "Confirm Delete", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                boolean success = ebookDAO.deleteEbook(ebookId);
                if (success) {
                    JOptionPane.showMessageDialog(this, "✅ E-Book deleted successfully.");
                    ebookIdField.setText("");
                } else {
                    JOptionPane.showMessageDialog(this, "❌ E-Book not found or delete failed.");
                }
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid E-Book ID.");
        }
    }
}

package ui;

import dao.SecondHandBookDAO;
import model.SecondHandBook;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class BuySecondHandBookUI extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private SecondHandBookDAO dao = new SecondHandBookDAO();

    public BuySecondHandBookUI() {
        setTitle("🛒 Buy Second-Hand Books");
        setSize(700, 400);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        model = new DefaultTableModel(new String[]{"ID", "Title", "Author", "Publisher", "Edition", "Condition", "Price", "Uploaded By"}, 0);
        table = new JTable(model);

        loadBooks();

        JButton buyBtn = new JButton("Buy Selected Book");
        buyBtn.addActionListener(e -> buyBook());

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(buyBtn, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void loadBooks() {
        model.setRowCount(0); // Clear table
        List<SecondHandBook> books = dao.getApprovedBooks();

        for (SecondHandBook book : books) {
            model.addRow(new Object[]{
                    book.getBookId(),
                    book.getTitle(),
                    book.getAuthor(),
                    book.getPublisher(),
                    book.getEdition(),
                    book.getBookCondition(), // replace getCondition()
                    "₹" + book.getPrice(),
                    book.getUploadedBy()
            });
        }
    }

    private void buyBook() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "⚠️ Please select a book to buy!");
            return;
        }

        int bookId = (int) model.getValueAt(row, 0);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Confirm purchase of this book?", "Confirm", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = SecondHandBookDAO.markAsSold(bookId); // static method
            if (success) {
                JOptionPane.showMessageDialog(this, "🎉 Purchase successful!");
                loadBooks(); // refresh list
            } else {
                JOptionPane.showMessageDialog(this, "❌ Error updating book status.");
            }
        }
    }
}

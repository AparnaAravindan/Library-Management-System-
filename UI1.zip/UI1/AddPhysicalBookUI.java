package ui;

import dao.BookDAO;
import model.Book;

import javax.swing.*;
import java.awt.*;

public class AddPhysicalBookUI extends JFrame {
    private JTextField titleField, authorField, categoryField, publisherField, editionField, isbnField, quantityField;

    public AddPhysicalBookUI() {
        setTitle("➕ Add Physical Book");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(8, 2, 10, 10));

        titleField = new JTextField();
        authorField = new JTextField();
        categoryField = new JTextField();
        publisherField = new JTextField();
        editionField = new JTextField();
        isbnField = new JTextField();
        quantityField = new JTextField();

        panel.add(new JLabel("Title:")); panel.add(titleField);
        panel.add(new JLabel("Author:")); panel.add(authorField);
        panel.add(new JLabel("Category:")); panel.add(categoryField);
        panel.add(new JLabel("Publisher:")); panel.add(publisherField);
        panel.add(new JLabel("Edition:")); panel.add(editionField);
        panel.add(new JLabel("ISBN:")); panel.add(isbnField);
        panel.add(new JLabel("Quantity:")); panel.add(quantityField);

        JButton addBtn = new JButton("Add Book");
        addBtn.addActionListener(e -> addBook());
        panel.add(new JLabel(""));
        panel.add(addBtn);

        add(panel);
        setVisible(true);
    }

    private void addBook() {
        try {
            Book book = new Book();
            book.setTitle(titleField.getText());
            book.setAuthor(authorField.getText());
            book.setCategory(categoryField.getText());
            book.setPublisher(publisherField.getText());
            book.setEdition(editionField.getText());
            book.setIsbn(isbnField.getText());
            book.setQuantity(Integer.parseInt(quantityField.getText()));
            book.setAvailable(true);

            boolean success = new BookDAO().addBook(book);
            if (success) {
                JOptionPane.showMessageDialog(this, "✅ Book added successfully!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "❌ Failed to add book.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "⚠️ Error: " + ex.getMessage());
        }
    }
}

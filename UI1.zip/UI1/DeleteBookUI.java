package ui;

import dao.BookDAO;

import javax.swing.*;
import java.awt.*;

public class DeleteBookUI extends JFrame {

    private JTextField bookIdField;
    private BookDAO bookDAO = new BookDAO();

    public DeleteBookUI() {
        setTitle("Delete Book");
        setSize(400, 200);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Layout
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));

        panel.add(new JLabel("Enter Book ID:"));
        bookIdField = new JTextField();
        panel.add(bookIdField);

        JButton deleteBtn = new JButton("Delete Book");
        JButton cancelBtn = new JButton("Cancel");

        panel.add(deleteBtn);
        panel.add(cancelBtn);

        add(panel, BorderLayout.CENTER);

        // ✅ Action for delete
        deleteBtn.addActionListener(e -> deleteBook());

        // Cancel button closes window
        cancelBtn.addActionListener(e -> dispose());

        setVisible(true);
    }

    private void deleteBook() {
        String idStr = bookIdField.getText().trim();
        if (idStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Book ID.");
            return;
        }

        try {
            int bookId = Integer.parseInt(idStr);

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete book ID " + bookId + "?",
                    "Confirm Delete", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                boolean success = bookDAO.deleteBook(bookId);
                if (success) {
                    JOptionPane.showMessageDialog(this, "✅ Book deleted successfully.");
                    bookIdField.setText("");
                } else {
                    JOptionPane.showMessageDialog(this, "❌ Book ID not found or delete failed.");
                }
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid Book ID.");
        }
    }
}

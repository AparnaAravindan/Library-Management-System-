package ui;

import dao.SecondHandBookDAO;
import model.SecondHandBook;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ApproveSecondHandBooksUI extends JFrame {
    private JTable table;
    private DefaultTableModel model;

    public ApproveSecondHandBooksUI() {
        setTitle("✅ Approve Second-Hand Books");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        model = new DefaultTableModel(new String[]{
                "ID", "Title", "Author", "Publisher", "Edition", "Condition", "Price", "Uploaded By", "Date"
        }, 0);

        table = new JTable(model);
        loadPendingBooks();

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel();
        JButton approveBtn = new JButton("Approve");
        JButton rejectBtn = new JButton("Reject");

        approveBtn.addActionListener(e -> updateStatus("approved"));
        rejectBtn.addActionListener(e -> updateStatus("rejected"));

        btnPanel.add(approveBtn);
        btnPanel.add(rejectBtn);

        add(btnPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void loadPendingBooks() {
        model.setRowCount(0);
        List<SecondHandBook> books = SecondHandBookDAO.getPendingBooks(); // ✅ only fetch books

        for (SecondHandBook b : books) {
            model.addRow(new Object[]{
                    b.getBookId(),
                    b.getTitle(),
                    b.getAuthor(),
                    b.getPublisher(),
                    b.getEdition(),
                    b.getBookCondition(),
                    b.getPrice(),
                    b.getUploadedBy(),
                    b.getUploadDate()
            });
        }
    }

    private void updateStatus(String status) {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "⚠️ Select a book first!");
            return;
        }

        // ✅ get bookId from table
        int bookId = (int) model.getValueAt(row, 0);

        // ✅ update via DAO
        boolean success = SecondHandBookDAO.updateBookStatus(bookId, status);

        if (success) {
            JOptionPane.showMessageDialog(this, "✅ Book " + status + " successfully!");
            loadPendingBooks(); // refresh after update
        } else {
            JOptionPane.showMessageDialog(this, "❌ Failed to update book status.");
        }
    }
}


package ui;

public class Main {
    public static void main(String[] args) {
        new LoginUI();  // Start the app at login page
    }
}



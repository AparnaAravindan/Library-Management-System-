package model;

public class SecondHandBook {
    private int bookId;
    private String title;
    private String author;
    private String publisher;
    private String edition;
    private String condition;
    private double price;
    private String photoPath;
    private String uploadedBy;
    private String status;
    private boolean sold;
    private String uploadDate; // Added

    // Original constructor
    public SecondHandBook(String title, String author, String publisher, String edition,
                          String condition, double price, String photoPath,
                          String uploadedBy, String status, boolean sold) {
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.edition = edition;
        this.condition = condition;
        this.price = price;
        this.photoPath = photoPath;
        this.uploadedBy = uploadedBy;
        this.status = status;
        this.sold = sold;
    }

    // New constructor for DAO/UI
    public SecondHandBook(int bookId, String title, String author, String publisher,
                          String edition, String condition, double price,
                          String photoPath, String uploadedBy, String status, String uploadDate) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.edition = edition;
        this.condition = condition;
        this.price = price;
        this.photoPath = photoPath;
        this.uploadedBy = uploadedBy;
        this.status = status;
        this.uploadDate = uploadDate;
    }

    // Empty constructor
    public SecondHandBook() {}

    // Getters and Setters
    public int getBookId() { return bookId; }
    public void setBookId(int bookId) { this.bookId = bookId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }

    public String getEdition() { return edition; }
    public void setEdition(String edition) { this.edition = edition; }

    public String getCondition() { return condition; }
    public void setCondition(String condition) { this.condition = condition; }

    public String getBookCondition() { return condition; } // added for UI consistency

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public String getPhotoPath() { return photoPath; }
    public void setPhotoPath(String photoPath) { this.photoPath = photoPath; }

    public String getUploadedBy() { return uploadedBy; }
    public void setUploadedBy(String uploadedBy) { this.uploadedBy = uploadedBy; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public boolean isSold() { return sold; }
    public void setSold(boolean sold) { this.sold = sold; }

    public String getUploadDate() { return uploadDate; } // added
    public void setUploadDate(String uploadDate) { this.uploadDate = uploadDate; }
}

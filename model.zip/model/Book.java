package model;

public class Book {
    private int bookId;
    private String title;
    private String author;
    private String category;
    private boolean available;

    // 🔹 New fields
    private String publisher;
    private String edition;
    private String isbn;
    private int quantity;

    // No-arg constructor
    public Book() {}

    // Existing all-arg constructor (for backward compatibility)
    public Book(int bookId, String title, String author, String category, boolean available) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.category = category;
        this.available = available;
    }

    // New all-arg constructor with extended fields
    public Book(int bookId, String title, String author, String category, boolean available,
                String publisher, String edition, String isbn, int quantity) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.category = category;
        this.available = available;
        this.publisher = publisher;
        this.edition = edition;
        this.isbn = isbn;
        this.quantity = quantity;
    }

    // Getters
    public int getBookId() { return bookId; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getCategory() { return category; }
    public boolean isAvailable() { return available; }
    public String getPublisher() { return publisher; }
    public String getEdition() { return edition; }
    public String getIsbn() { return isbn; }
    public int getQuantity() { return quantity; }

    // Setters
    public void setBookId(int bookId) { this.bookId = bookId; }
    public void setTitle(String title) { this.title = title; }
    public void setAuthor(String author) { this.author = author; }
    public void setCategory(String category) { this.category = category; }
    public void setAvailable(boolean available) { this.available = available; }
    public void setPublisher(String publisher) { this.publisher = publisher; }
    public void setEdition(String edition) { this.edition = edition; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
}



package model;

public class DonatedBook {
    private int donateId;
    private String title;
    private String author;
    private String publisher;
    private String edition;
    private String bookCondition;
    private String photoPath;
    private String uploadedBy;   // ✅ instead of userId
    private String status;
    private String uploadDate;
    private String isbn;         // ✅ NEW field

    // ✅ Constructor for new donation (student submitting book)
    public DonatedBook(String title, String author, String publisher, String edition,
                       String bookCondition, String photoPath, String uploadedBy, 
                       String status, String isbn) {
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.edition = edition;
        this.bookCondition = bookCondition;
        this.photoPath = photoPath;
        this.uploadedBy = uploadedBy;
        this.status = status;
        this.isbn = isbn;
    }

    // ✅ Full constructor (used when reading from DB)
    public DonatedBook(int donateId, String title, String author, String publisher, String edition,
                       String bookCondition, String photoPath, String uploadedBy,
                       String status, String uploadDate, String isbn) {
        this.donateId = donateId;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.edition = edition;
        this.bookCondition = bookCondition;
        this.photoPath = photoPath;
        this.uploadedBy = uploadedBy;
        this.status = status;
        this.uploadDate = uploadDate;
        this.isbn = isbn;
    }

    // Getters and Setters
    public int getDonateId() { return donateId; }
    public void setDonateId(int donateId) { this.donateId = donateId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }

    public String getEdition() { return edition; }
    public void setEdition(String edition) { this.edition = edition; }

    public String getBookCondition() { return bookCondition; }
    public void setBookCondition(String bookCondition) { this.bookCondition = bookCondition; }

    public String getPhotoPath() { return photoPath; }
    public void setPhotoPath(String photoPath) { this.photoPath = photoPath; }

    public String getUploadedBy() { return uploadedBy; }
    public void setUploadedBy(String uploadedBy) { this.uploadedBy = uploadedBy; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getUploadDate() { return uploadDate; }
    public void setUploadDate(String uploadDate) { this.uploadDate = uploadDate; }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
}

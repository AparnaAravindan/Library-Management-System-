package model;

import java.time.LocalDate;

public class FineRecord {
    private String username;
    private String bookTitle;
    private LocalDate dueDate;
    private LocalDate returnDate;
    private int fine;

    public FineRecord(String username, String bookTitle, LocalDate dueDate, LocalDate returnDate, int fine) {
        this.username = username;
        this.bookTitle = bookTitle;
        this.dueDate = dueDate;
        this.returnDate = returnDate;
        this.fine = fine;
    }

    public String getUsername() { return username; }
    public String getBookTitle() { return bookTitle; }
    public LocalDate getDueDate() { return dueDate; }
    public LocalDate getReturnDate() { return returnDate; }
    public int getFine() { return fine; }
}

package model;

public class Ebook {
    private int ebookId;
    private String title;
    private String subject;
    private String author;
    private String filePath;
    private String uploadedBy;
    private String status;

    // Getters and setters
    public int getEbookId() { return ebookId; }
    public void setEbookId(int ebookId) { this.ebookId = ebookId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }

    public String getUploadedBy() { return uploadedBy; }
    public void setUploadedBy(String uploadedBy) { this.uploadedBy = uploadedBy; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}

package ui;

import dao.BookDAO;
import model.Book;

import javax.swing.*;
import java.awt.*;

public class UpdateBookUI extends JFrame {
    private JTextField idField, titleField, authorField, categoryField, publisherField, editionField, isbnField, qtyField;
    private JButton loadBtn, updateBtn;
    private BookDAO bookDAO = new BookDAO();

    public UpdateBookUI() {
        setTitle("Update Physical Book");
        setSize(400, 400);
        setLayout(new GridLayout(10, 2, 5, 5));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        add(new JLabel("Book ID:"));
        idField = new JTextField();
        add(idField);

        loadBtn = new JButton("Load");
        add(loadBtn);
        add(new JLabel("")); // filler

        add(new JLabel("Title:"));
        titleField = new JTextField();
        add(titleField);

        add(new JLabel("Author:"));
        authorField = new JTextField();
        add(authorField);

        add(new JLabel("Category:"));
        categoryField = new JTextField();
        add(categoryField);

        add(new JLabel("Publisher:"));
        publisherField = new JTextField();
        add(publisherField);

        add(new JLabel("Edition:"));
        editionField = new JTextField();
        add(editionField);

        add(new JLabel("ISBN:"));
        isbnField = new JTextField();
        add(isbnField);

        add(new JLabel("Quantity:"));
        qtyField = new JTextField();
        add(qtyField);

        updateBtn = new JButton("Update");
        add(updateBtn);

        loadBtn.addActionListener(e -> loadBook());
        updateBtn.addActionListener(e -> updateBook());
    }

    private void loadBook() {
        try {
            int bookId = Integer.parseInt(idField.getText());
            Book book = bookDAO.getBookById(bookId);
            if (book == null) {
                JOptionPane.showMessageDialog(this, "Book not found.");
                return;
            }
            titleField.setText(book.getTitle());
            authorField.setText(book.getAuthor());
            categoryField.setText(book.getCategory());
            publisherField.setText(book.getPublisher());
            editionField.setText(book.getEdition());
            isbnField.setText(book.getIsbn());
            qtyField.setText(String.valueOf(book.getQuantity()));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid input.");
        }
    }

    private void updateBook() {
        try {
            int bookId = Integer.parseInt(idField.getText());
            Book book = new Book();
            book.setBookId(bookId);
            book.setTitle(titleField.getText());
            book.setAuthor(authorField.getText());
            book.setCategory(categoryField.getText());
            book.setPublisher(publisherField.getText());
            book.setEdition(editionField.getText());
            book.setIsbn(isbnField.getText());
            book.setQuantity(Integer.parseInt(qtyField.getText()));

            boolean success = bookDAO.updateBook(book);
            if (success) {
                JOptionPane.showMessageDialog(this, "Book updated successfully!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update book.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid input.");
        }
    }
}

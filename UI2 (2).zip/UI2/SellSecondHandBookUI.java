package ui;

import dao.SecondHandBookDAO;
import model.SecondHandBook;

import javax.swing.*;
import java.awt.*;

public class SellSecondHandBookUI extends JFrame {
    private JTextField titleField, authorField, publisherField, editionField, priceField;
    private JComboBox<String> conditionBox;
    private String username;

    public SellSecondHandBookUI(String username) {
        this.username = username;

        setTitle("💰 Sell Second-Hand Book");
        setSize(400, 400);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(7, 2, 10, 10));

        panel.add(new JLabel("Title:"));
        titleField = new JTextField();
        panel.add(titleField);

        panel.add(new JLabel("Author:"));
        authorField = new JTextField();
        panel.add(authorField);

        panel.add(new JLabel("Publisher:"));
        publisherField = new JTextField();
        panel.add(publisherField);

        panel.add(new JLabel("Edition:"));
        editionField = new JTextField();
        panel.add(editionField);

        panel.add(new JLabel("Condition:"));
        conditionBox = new JComboBox<>(new String[]{"Bad", "Average", "New"});
        panel.add(conditionBox);

        panel.add(new JLabel("Price (₹):"));
        priceField = new JTextField();
        panel.add(priceField);

        JButton submitBtn = new JButton("✅ Submit for Approval");
        JButton cancelBtn = new JButton("❌ Cancel");

        panel.add(submitBtn);
        panel.add(cancelBtn);

        add(panel);

        submitBtn.addActionListener(e -> submitBook());
        cancelBtn.addActionListener(e -> dispose());

        setVisible(true);
    }

    private void submitBook() {
        String title = titleField.getText().trim();
        String author = authorField.getText().trim();
        String publisher = publisherField.getText().trim();
        String edition = editionField.getText().trim();
        String condition = conditionBox.getSelectedItem().toString();
        String priceText = priceField.getText().trim();

        if (title.isEmpty() || priceText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠️ Title and Price are required!");
            return;
        }

        double price;
        try { price = Double.parseDouble(priceText); }
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "⚠️ Price must be a number!");
            return;
        }

        SecondHandBook book = new SecondHandBook(
                title, author, publisher, edition,
                condition, price, null, username,
                "pending", false
        );

        boolean saved = SecondHandBookDAO.saveBook(book); // static method
        if (saved) {
            JOptionPane.showMessageDialog(this, "🎉 Book submitted! Awaiting admin approval.");
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "❌ Error submitting book.");
        }
    }
}

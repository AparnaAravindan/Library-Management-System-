package ui;

import dao.SecondHandBookDAO;
import model.SecondHandBook;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ViewSecondHandBooksUI extends JFrame {
    private JTable table;
    private DefaultTableModel model;

    public ViewSecondHandBooksUI() {
        setTitle("📖 Approved Second-Hand Books");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        model = new DefaultTableModel(new String[]{
                "ID", "Title", "Author", "Publisher", "Edition", "Condition", "Price", "Uploaded By", "Date"
        }, 0);

        table = new JTable(model);
        loadApprovedBooks();

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        setVisible(true);
    }

    private void loadApprovedBooks() {
        model.setRowCount(0);
        List<SecondHandBook> books = SecondHandBookDAO.getApprovedBooks(); // static method
        for (SecondHandBook b : books) {
            model.addRow(new Object[]{
                    b.getBookId(),
                    b.getTitle(),
                    b.getAuthor(),
                    b.getPublisher(),
                    b.getEdition(),
                    b.getBookCondition(),
                    b.getPrice(),
                    b.getUploadedBy(),
                    b.getUploadDate()
            });
        }
    }
}


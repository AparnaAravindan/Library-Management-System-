// LoginUI.java
package ui;

import dao.UserDAO;
import model.User;

import javax.swing.*;
import java.awt.*;

public class LoginUI extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> roleBox;
    private UserDAO userDAO = new UserDAO();

    public LoginUI() {
        setTitle("Library Login");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 2, 10, 10));

        // Username
        add(new JLabel("Username:"));
        usernameField = new JTextField();
        add(usernameField);

        // Password
        add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        add(passwordField);

        // Role
        add(new JLabel("Role:"));
        roleBox = new JComboBox<>(new String[]{"student", "librarian"});
        add(roleBox);

        // Buttons
        JButton loginBtn = new JButton("Login");
        JButton registerBtn = new JButton("Register");
        add(loginBtn);
        add(registerBtn);

        // ✅ Login button action
        loginBtn.addActionListener(e -> {
            String user = usernameField.getText().trim();
            String pass = new String(passwordField.getPassword()).trim();
            String role = roleBox.getSelectedItem().toString();

            User loggedInUser = userDAO.login(user, pass, role);

            if (loggedInUser != null) {
                JOptionPane.showMessageDialog(this, "✅ Login Successful as " + role);
                dispose();
                if (role.equals("student")) {
                    new StudentDashboard(loggedInUser).setVisible(true);
                } else {
                    new AdminDashboard(loggedInUser).setVisible(true);
                }

            } else {
                JOptionPane.showMessageDialog(this, "❌ Invalid credentials");
            }
        });

        // ✅ Register button action
        registerBtn.addActionListener(e -> {
            dispose();
            new RegisterUI().setVisible(true);
        });

        setLocationRelativeTo(null); // center the window
        setVisible(true);
    }

    public static void main(String[] args) {
        new LoginUI();
    }
}



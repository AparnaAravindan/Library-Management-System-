package ui;

import model.User;

import javax.swing.*;
import java.awt.*;

public class SecondHandBookUI extends JFrame {
    private final User loggedInUser;

    public SecondHandBookUI(User user) {
        this.loggedInUser = user;

        setTitle("📖 Second-Hand Books");
        setSize(300, 200);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(2, 1, 10, 10));

        JButton sellBtn = new JButton("💰 Sell Second-Hand Book");
        JButton buyBtn = new JButton("🛒 Buy Second-Hand Book");

        panel.add(sellBtn);
        panel.add(buyBtn);

        add(panel);

        sellBtn.addActionListener(e -> new SellSecondHandBookUI(loggedInUser.getUsername()).setVisible(true));
        buyBtn.addActionListener(e -> new BuySecondHandBookUI().setVisible(true));

        setVisible(true);
    }
}

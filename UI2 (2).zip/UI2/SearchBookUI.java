package ui;

import dao.BookDAO;
import dao.BorrowDAO;
import model.Book;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class SearchBookUI extends JFrame {

    private int userId; // -1 for admin, >0 for students
    private JTextField searchField;
    private JTable table;
    private BookDAO bookDAO = new BookDAO();
    private BorrowDAO borrowDAO = new BorrowDAO();

    // ✅ Constructor for student (pass userId)
    public SearchBookUI(int userId) {
        this.userId = userId;
        initUI();
    }

    // ✅ No-argument constructor for admin
    public SearchBookUI() {
        this.userId = -1; // indicates admin
        initUI();
    }

    // Shared UI initialization
    private void initUI() {
        setTitle("Search Books");
        setSize(700, 450);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Top panel: search field + button
        JPanel top = new JPanel(new BorderLayout(6, 6));
        searchField = new JTextField();
        JButton searchBtn = new JButton("Search");
        top.add(new JLabel("Search:"), BorderLayout.WEST);
        top.add(searchField, BorderLayout.CENTER);
        top.add(searchBtn, BorderLayout.EAST);
        add(top, BorderLayout.NORTH);

        // Table to show books
        table = new JTable();
        add(new JScrollPane(table), BorderLayout.CENTER);

        // Bottom panel: borrow button only for students
        if (userId > 0) {
            JPanel bottom = new JPanel();
            JButton borrowBtn = new JButton("Borrow Selected Book");
            bottom.add(borrowBtn);
            add(bottom, BorderLayout.SOUTH);

            borrowBtn.addActionListener(e -> borrowSelected());
        }

        // Button actions
        searchBtn.addActionListener(e -> loadResults());

        setVisible(true);
    }

    // Load search results
    private void loadResults() {
        String kw = searchField.getText().trim();
        List<Book> books = bookDAO.searchBooks(kw);
        String[] cols = {"Book ID", "Title", "Author", "Category", "Available"};
        DefaultTableModel m = new DefaultTableModel(cols, 0);
        for (Book b : books) {
            m.addRow(new Object[]{b.getBookId(), b.getTitle(), b.getAuthor(), b.getCategory(), b.isAvailable()});
        }
        table.setModel(m);
    }

    // Borrow selected book (only for students)
    private void borrowSelected() {
        int r = table.getSelectedRow();
        if (r < 0) {
            JOptionPane.showMessageDialog(this, "Please select a book first.");
            return;
        }
        int bookId = (int) table.getModel().getValueAt(r, 0);

        int confirm = JOptionPane.showConfirmDialog(this, "Borrow book ID " + bookId + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        boolean ok = borrowDAO.borrowBook(userId, bookId);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Book borrowed successfully!");
            loadResults();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to borrow (no copies available or error).");
        }
    }
}



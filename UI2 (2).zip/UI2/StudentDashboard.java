package ui;

import model.User;
import dao.BookDAO;
import dao.BorrowDAO;

import javax.swing.*;
import java.awt.*;

public class StudentDashboard extends JFrame {

    private User loggedInUser;
    private BookDAO bookDAO = new BookDAO();
    private BorrowDAO borrowDAO = new BorrowDAO(); // ✅ use BorrowDAO for borrow/return

    public StudentDashboard(User user) {
        this.loggedInUser = user;

        setTitle("Student Dashboard - " + user.getUsername());
        setSize(500, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(8, 1, 10, 10));

        JLabel welcomeLabel = new JLabel("Welcome, " + user.getUsername(), JLabel.CENTER);
        panel.add(welcomeLabel);

        JButton searchBookBtn = new JButton("🔍 Search Books");
        JButton borrowBookBtn = new JButton("📚 Borrow Book");
        JButton returnBookBtn = new JButton("↩️ Return Book");
        JButton ebooksBtn = new JButton("💻 E-Books");
        JButton donateBookBtn = new JButton("🎁 Donate Book");
        JButton secondHandBtn = new JButton("📖 Second-hand Books");
        JButton logoutBtn = new JButton("🚪 Logout");

        panel.add(searchBookBtn);
        panel.add(borrowBookBtn);
        panel.add(returnBookBtn);
        panel.add(ebooksBtn);
        panel.add(donateBookBtn);
        panel.add(secondHandBtn);
        panel.add(logoutBtn);

        add(panel);

        // ✅ Pass userId to SearchBookUI
        searchBookBtn.addActionListener(e -> new SearchBookUI(loggedInUser.getUserId()));

        // Borrow book
        borrowBookBtn.addActionListener(e -> {
            String bookIdStr = JOptionPane.showInputDialog(this, "Enter Book ID to borrow:");
            if (bookIdStr != null) {
                try {
                    int bookId = Integer.parseInt(bookIdStr);
                    boolean success = borrowDAO.borrowBook(loggedInUser.getUserId(), bookId); // ✅ use borrowDAO
                    if (success) {
                        JOptionPane.showMessageDialog(this, "✅ Book borrowed successfully!");
                    } else {
                        JOptionPane.showMessageDialog(this, "❌ Book not available or invalid ID.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "❌ Invalid Book ID.");
                }
            }
        });

        // Return book (works for both self-borrowed & admin-issued books)
        returnBookBtn.addActionListener(e -> {
            String bookIdStr = JOptionPane.showInputDialog(this, "Enter Book ID to return:");
            if (bookIdStr != null) {
                try {
                    int bookId = Integer.parseInt(bookIdStr);
                    boolean success = borrowDAO.returnBook(loggedInUser.getUserId(), bookId); // ✅ new method
                    if (success) {
                        JOptionPane.showMessageDialog(this, "✅ Book returned successfully!");
                    } else {
                        JOptionPane.showMessageDialog(this, "❌ Book not borrowed by you or already returned.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "❌ Invalid Book ID.");
                }
            }
        });

        // Other UI buttons
        ebooksBtn.addActionListener(e -> new EbookUI(loggedInUser.getUsername()).setVisible(true));
        donateBookBtn.addActionListener(e -> new DonateBookUI(loggedInUser.getUsername()).setVisible(true));
        secondHandBtn.addActionListener(e -> new SecondHandBookUI(loggedInUser).setVisible(true));

        logoutBtn.addActionListener(e -> {
            dispose();
            new LoginUI();
        });

        setVisible(true);
    }
}




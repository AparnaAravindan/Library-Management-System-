package ui;

import javax.swing.*;
import dao.UserDAO;
import java.awt.*;
import java.awt.event.*;

public class RegisterUI extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> roleBox;
    private JButton registerButton, backButton;

    public RegisterUI() {
        setTitle("Register");
        setSize(350, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));

        // Fields
        panel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        panel.add(usernameField);

        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        panel.add(new JLabel("Role:"));
        roleBox = new JComboBox<>(new String[]{"student", "librarian"});
        panel.add(roleBox);

        // Buttons
        registerButton = new JButton("Register");
        backButton = new JButton("Back to Login");
        panel.add(registerButton);
        panel.add(backButton);

        add(panel);

        UserDAO dao = new UserDAO(); // create DAO once

        // ✅ Register button action
        registerButton.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();
            String role = (String) roleBox.getSelectedItem();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields!");
                return;
            }

            boolean success = dao.registerUser(username, password, role);

            if (success) {
                JOptionPane.showMessageDialog(this, "✅ Registration successful!");
                dispose();
                new LoginUI().setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "⚠️ Registration failed! Username may already exist.");
            }
        });

        // ✅ Back button action
        backButton.addActionListener(e -> {
            dispose();
            new LoginUI().setVisible(true);
        });

        setVisible(true);
    }
}

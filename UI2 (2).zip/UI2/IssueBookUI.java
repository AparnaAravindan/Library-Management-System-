package ui;

import dao.BorrowDAO;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class IssueBookUI extends JFrame {

    private JTextField userIdField;
    private JTextField bookIdField;
    private JButton issueBtn;
    private BorrowDAO borrowDAO = new BorrowDAO();

    public IssueBookUI() {
        setTitle("Admin - Issue Book");
        setSize(400, 200);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(3, 2, 10, 10));

        // User ID
        add(new JLabel("Enter Student User ID:"));
        userIdField = new JTextField();
        add(userIdField);

        // Book ID
        add(new JLabel("Enter Book ID:"));
        bookIdField = new JTextField();
        add(bookIdField);

        // Empty label for spacing
        add(new JLabel());

        // Issue Button
        issueBtn = new JButton("Issue Book");
        add(issueBtn);

        // Button action
        issueBtn.addActionListener(e -> issueBook());

        setVisible(true);
    }

    private void issueBook() {
        try {
            int userId = Integer.parseInt(userIdField.getText().trim());
            int bookId = Integer.parseInt(bookIdField.getText().trim());

            // Call BorrowDAO to insert borrow record
            boolean success = borrowDAO.adminIssueBook(userId, bookId);

            if (success) {
                JOptionPane.showMessageDialog(this, "Book issued successfully! Due date = today + 14 days");
                userIdField.setText("");
                bookIdField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to issue book. Check if book is available or IDs are correct.");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numeric IDs.");
        }
    }

    // To test standalone
    public static void main(String[] args) {
        new IssueBookUI();
    }
}

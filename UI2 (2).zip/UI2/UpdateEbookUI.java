package ui;

import dao.EbookDAO;
import model.Ebook;

import javax.swing.*;
import java.awt.*;

public class UpdateEbookUI extends JFrame {
    private JTextField idField, titleField, filePathField, uploadedByField;
    private JButton loadBtn, updateBtn;
    private EbookDAO ebookDAO = new EbookDAO();

    public UpdateEbookUI() {
        setTitle("Update E-Book");
        setSize(400, 300);
        setLayout(new GridLayout(6, 2, 5, 5));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        add(new JLabel("E-Book ID:"));
        idField = new JTextField();
        add(idField);

        loadBtn = new JButton("Load");
        add(loadBtn);
        add(new JLabel(""));

        add(new JLabel("Title:"));
        titleField = new JTextField();
        add(titleField);

        add(new JLabel("File Path:"));
        filePathField = new JTextField();
        add(filePathField);

        add(new JLabel("Uploaded By:"));
        uploadedByField = new JTextField();
        add(uploadedByField);

        updateBtn = new JButton("Update");
        add(updateBtn);

        loadBtn.addActionListener(e -> loadEbook());
        updateBtn.addActionListener(e -> updateEbook());
    }

    private void loadEbook() {
        try {
            int ebookId = Integer.parseInt(idField.getText());
            Ebook ebook = ebookDAO.getEbookById(ebookId);
            if (ebook == null) {
                JOptionPane.showMessageDialog(this, "E-Book not found.");
                return;
            }
            titleField.setText(ebook.getTitle());
            filePathField.setText(ebook.getFilePath());
            uploadedByField.setText(ebook.getUploadedBy());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid input.");
        }
    }

    private void updateEbook() {
        try {
            int ebookId = Integer.parseInt(idField.getText());
            Ebook ebook = new Ebook();
            ebook.setEbookId(ebookId);
            ebook.setTitle(titleField.getText());
            ebook.setFilePath(filePathField.getText());
            ebook.setUploadedBy(uploadedByField.getText());

            boolean success = ebookDAO.updateEbook(ebook);
            if (success) {
                JOptionPane.showMessageDialog(this, "E-Book updated successfully!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update E-Book.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid input.");
        }
    }
}
